<?php
    $pagina = 'Quem Somos - Projeto 2';
    $wrap = 'wrap-login100';
    require('navbar.php');
    require('head.php');
?>
<div>
<p>Desenvolvido por <a href="https://fb.com/arthur.mooura" class="perfil">Arthur Moura</a> & <a href="https://fb.com/humberto.eduardo.77">Humberto Ribeiro</a></p>
<div>