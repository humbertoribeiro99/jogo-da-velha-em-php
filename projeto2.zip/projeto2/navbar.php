<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <p class="navbar-brand" href="#">Projeto 2</p>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Alterna navegação">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Inicio <span class="sr-only">(página atual)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="info.php">Quem Somos</a>
      </li>
    </ul>
    <button onclick="location.href='logoff.php'" class="btn btn-outline-success my-2 my-sm-0" >Sair</button>
  </div>
</nav>

