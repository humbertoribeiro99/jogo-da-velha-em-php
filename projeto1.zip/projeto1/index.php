<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jogo da Velha</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
        <h1>Bem vindo ao Jogo da Velha</h1>
        <h3>Escolha entre X e O para começar o jogo</h3>
        <div class="jogador">
        <a href="jogadorX.php" >
            <img src="img\x.png" />
        </a>
        <a href="jogadorO.php" >
            <img src="img\o.png">
        </a>
        </div>
 
</body>
</html>