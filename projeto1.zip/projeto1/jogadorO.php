<?php
session_start();
$_SESSION = $_POST;
$vencedor = 'neutro';
$campo = array('','','','','','','','','');
    if(isset($_POST['playbtn'])){
        $campo[0] = $_POST["campo0"];
        $campo[1] = $_POST["campo1"];
        $campo[2] = $_POST["campo2"];
        $campo[3] = $_POST["campo3"];
        $campo[4] = $_POST["campo4"];
        $campo[5] = $_POST["campo5"];
        $campo[6] = $_POST["campo6"];
        $campo[7] = $_POST["campo7"];
        $campo[8] = $_POST["campo8"];

        //verificando os campos para definir um campeão
        if(($campo[0] == 'o' && $campo[1] == 'o' && $campo[2] == 'o')  || ($campo[3] == 'o' && $campo[4] == 'o' && $campo[5] == 'o') || ($campo[6] == 'o' && $campo[7] == 'o' && $campo[8] == 'o') || ($campo[0] == 'o' && $campo[3] == 'o' && $campo[6] == 'o')  || ($campo[1] == 'o' && $campo[4] == 'o' && $campo[7] == 'o') || ($campo[2] == 'o' && $campo[5] == 'o' && $campo[8] == 'o') || ($campo[0] == 'o' && $campo[4] == 'o' && $campo[8] == 'o') || ($campo[2] == 'o' && $campo[4] == 'o' && $campo[6] == 'o')){
            $vencedor = 'o';
            echo "<h2 class='resutado'>O Jogador(O) ganhou</h2>";
        }

        $vazio = 0;
        for($i = 0; $i <= 8; $i++){
            if($campo[$i] == ''){
                $vazio = 1;
            }
        }
        if($vazio == 1){
            $i = rand() % 8;
            while($campo[$i] != ''){
                $i = rand() % 8;
            }
            $campo[$i] = 'x';
            if(($campo[0] == 'x' && $campo[1] == 'x' && $campo[2] == 'x')  || ($campo[3] == 'x' && $campo[4] == 'x' && $campo[5] == 'x') || ($campo[6] == 'x' && $campo[7] == 'x' && $campo[8] == 'x') || ($campo[0] == 'x' && $campo[3] == 'x' && $campo[6] == 'x')  || ($campo[1] == 'x' && $campo[4] == 'x' && $campo[7] == 'x') || ($campo[2] == 'x' && $campo[5] == 'x' && $campo[8] == 'x') || ($campo[0] == 'x' && $campo[4] == 'x' && $campo[8] == 'x') || ($campo[2] == 'x' && $campo[4] == 'x' && $campo[6] == 'x')){
                $vencedor = 'x';
                echo "<h2 class='resultado'>A Maquina(X) ganhou</h2>";
            }
        }
        else if ($vencedor == 'neutro'){
            $vencedor = 'e';
            echo "<h2 class='resultado'>Empatou</h2>";
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jogo da Velha</title>
    <link rel="stylesheet" href="style.css">
    <script>
        function playJogo() {
          window.location.assign("jogovelha.php")
        }
    </script>
</head>
<body>
  <div style="margin:0 auto;width:75%;text-align:center;">
  <h1>Jogo da Velha</h1>
	<form name = "jogovelha" method = "post" action = "jogadorO.php">
        <?php
			for($i = 0; $i <=8; $i++)
			{
                printf('<input type = "text" id = "tabuleiro" name = "campo%s" value = "%s">', $i, $campo[$i]);
                /* o printf é usado para passar uma string foramtada. 
                é passado os parametros do html e depois ele formata a 
                string usando os valores 'vazios' dos arrays campos lá no php (o '%s' converte a sequencia em string, por isso cria a tabela) */
				if ($i == 2 || $i == 5 || $i == 8){
                    echo("<br>");
                    /* O if aqui faz a quebra para que se pareça uma tabela 3x3, 
                    quando ele chega nos valores do array[2][5][8], que é o terceiro de cada linha 
                    usa o <br> para quebrar a linha, deixando semelhante a um campo de jogo da velha
                    */
				}
			}
			if($vencedor == 'neutro'){
                echo('<input type = "submit" name = "playbtn" value = "Jogar" id = "go">');
            } 
			else
			{
				echo('<input type = "button" name = "novojogo" value = "Novo Jogo" id = "novo" onclick = "window.location.href=\'index.php\'">');
			}
		?>
    </form>
    </div>
  </div>
</body>
</html>